/**
 * SD, 2020
 * 
 * Lab #8, Binary Tree
 * 
 * Task #2 - Binary Tree implementation (test file)
 */

#include <stdio.h>
#include <stdlib.h>
#include "utils.h"
#include "queue.h"
#include "binary_tree.h"


int check_complete(b_tree_t *b_tree)
{
    /* TODO */
    /* return 1/0 if binary tree is complete or not */
    return 0;
}

void read_tree(b_tree_t *b_tree)
{
    int i, data, N;

    scanf("%d\n", &N);

    for (i = 0; i < N; ++i) {
        scanf("%d ", &data);
        b_tree_insert(b_tree, data);
    }
}

int main(void)
{
    b_tree_t *binary_tree;

    binary_tree = b_tree_create();

    read_tree(binary_tree);

    printf("%d\n", check_complete(binary_tree));

    /* remove one branch of the tree */
    DIE(binary_tree->root == NULL, "binary_tree root null");
    DIE(binary_tree->root->left == NULL, "binary_tree->left root null");
    DIE(binary_tree->root->left->left == NULL,
            "binary_tree->left->left root null");

    __b_tree_free(binary_tree->root->left->left);
    binary_tree->root->left->left = NULL;

    printf("%d\n", check_complete(binary_tree));

    b_tree_free(binary_tree);

    return 0;
}

#include <stdlib.h>
#include <stdio.h>

#include "ListGraph.h"

void init_list_graph(ListGraph *graph, int nodes) {
    /* TODO */
}

void add_edge_list_graph(ListGraph *graph, int src, int *dest) {
    /* TODO */
}

int has_edge_list_graph(ListGraph *graph, int src, int dest) {
    /* TODO */
}

LinkedList* get_neighbours_list_graph(ListGraph *graph, int node) {
    /* TODO */
}

void remove_edge_list_graph(ListGraph *graph, int src, int dest) {
    /* TODO */
}

void clear_list_graph(ListGraph *graph) {
    /* TODO */
}
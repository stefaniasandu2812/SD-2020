#include <stdlib.h>

#include "Queue.h"

void init_q(struct Queue *q) {
    q->list = malloc(sizeof(struct LinkedList));
    if (q->list == NULL) {
        perror("Not enough memory to initialize the queue!");
        return;
    }

    init_list(q->list);
}

int get_size_q(struct Queue *q) {
    /* TODO */
}

int is_empty_q(struct Queue *q) {
    /* TODO */
}

void* front(struct Queue *q) {
    /* TODO */
}

void dequeue(struct Queue *q) {
    /* TODO */
}

void enqueue(struct Queue *q, void *new_data) {
    /* TODO */
}

void clear_q(struct Queue *q) {
    /* TODO */
}

void purge_q(struct Queue *q) {
    /* TODO */
}